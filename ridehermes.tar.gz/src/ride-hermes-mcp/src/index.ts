#!/usr/bin/env node
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { HermesClient } from "./hermes-client.js";

const args = process.argv.slice(2);

if (args[0] === "setup") {
  const { main } = await import("./setup.js");
  await main();
  process.exit(0);
}

const client = new HermesClient();

if (!client.hasCredentials()) {
  console.error("╔══════════════════════════════════════════════════════════╗");
  console.error("║  🚗 RideHermes MCP Server — 未配置凭证                  ║");
  console.error("╠══════════════════════════════════════════════════════════╣");
  console.error("║                                                          ║");
  console.error("║  请先运行安装向导配置您的 API Key 和 User ID：            ║");
  console.error("║                                                          ║");
  console.error("║    npx ridehermes-mcp-server setup                       ║");
  console.error("║                                                          ║");
  console.error("║  获取凭证：RideHermes App →「我的」→「智能体授权」        ║");
  console.error("║                                                          ║");
  console.error("║  或直接设置环境变量：                                     ║");
  console.error("║    RIDEHERMES_API_KEY=rh_xxx                             ║");
  console.error("║    RIDEHERMES_USER_ID=<your_user_id>                     ║");
  console.error("║                                                          ║");
  console.error("╚══════════════════════════════════════════════════════════╝");
  process.exit(1);
}

const server = new McpServer({
  name: "ride-hermes-mcp",
  version: "1.2.0",
});

server.tool(
  "ride_estimate",
  "预估行程费用和时间。不需要下单，仅用于用户确认前查看价格。",
  {
    pickup_addr: z.string().describe("上车点地址或地标名称"),
    dropoff_addr: z.string().describe("下车点地址或地标名称"),
    car_type: z.number().default(1).describe("1=快车, 2=专车, 3=豪华车"),
  },
  async (args) => {
    const result = await client.estimate(args);
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }
);

server.tool(
  "ride_book",
  "叫车：创建出行订单并自动派单。调用前建议先用 ride_estimate 让用户确认价格。",
  {
    pickup_addr: z.string().describe("上车点地址"),
    dropoff_addr: z.string().describe("下车点地址"),
    pickup_lat: z.number().optional().describe("上车点纬度，不填则通过地址解析"),
    pickup_lng: z.number().optional().describe("上车点经度，不填则通过地址解析"),
    dropoff_lat: z.number().optional().describe("下车点纬度，不填则通过地址解析"),
    dropoff_lng: z.number().optional().describe("下车点经度，不填则通过地址解析"),
    car_type: z.number().default(1).describe("1=快车, 2=专车, 3=豪华车"),
    departure_time: z.string().optional().describe("预约时间 ISO8601，不填立即用车"),
  },
  async (args) => {
    const result = await client.book(args);
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }
);

server.tool(
  "ride_status",
  "查询订单状态、司机信息和位置",
  { order_id: z.string().describe("订单号或订单ID") },
  async (args) => {
    const result = await client.status(args.order_id);
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }
);

server.tool(
  "ride_cancel",
  "取消订单（仅在状态1/2/3时可取消）",
  {
    order_id: z.string().describe("订单号或订单ID"),
    reason: z.string().optional().describe("取消原因"),
  },
  async (args) => {
    await client.cancel(args.order_id, args.reason);
    return { content: [{ type: "text", text: JSON.stringify({ success: true, message: "订单已取消" }) }] };
  }
);

server.tool(
  "ride_history",
  "查询用户的历史订单",
  { limit: z.number().default(10).describe("返回数量，默认10，最大50") },
  async (args) => {
    const result = await client.history(args.limit);
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }
);

const transport = new StdioServerTransport();
await server.connect(transport);
