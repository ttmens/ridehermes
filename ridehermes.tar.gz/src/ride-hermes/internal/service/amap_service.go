package service

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"time"
)

type AmapService struct {
	apiKey string
	client *http.Client
}

type GeocodeResult struct {
	Address  string  `json:"address"`
	Lat      float64 `json:"lat"`
	Lng      float64 `json:"lng"`
	Resolved bool    `json:"resolved"`
}

func NewAmapService(apiKey string) *AmapService {
	return &AmapService{
		apiKey: apiKey,
		client: &http.Client{Timeout: 10 * time.Second},
	}
}

func (s *AmapService) Geocode(address string) (*GeocodeResult, error) {
	if s.apiKey == "" {
		return &GeocodeResult{Address: address, Resolved: false}, nil
	}

	params := url.Values{}
	params.Set("key", s.apiKey)
	params.Set("address", address)
	params.Set("output", "JSON")

	resp, err := s.client.Get(fmt.Sprintf("https://restapi.amap.com/v3/geocode/geo?%s", params.Encode()))
	if err != nil {
		return &GeocodeResult{Address: address, Resolved: false}, fmt.Errorf("地理编码请求失败: %w", err)
	}
	defer resp.Body.Close()

	var result struct {
		Status   string `json:"status"`
		Geocodes []struct {
			Location string `json:"location"`
		} `json:"geocodes"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return &GeocodeResult{Address: address, Resolved: false}, nil
	}

	if result.Status != "1" || len(result.Geocodes) == 0 {
		return &GeocodeResult{Address: address, Resolved: false}, nil
	}

	location := result.Geocodes[0].Location
	var lng, lat float64
	if _, err := fmt.Sscanf(location, "%f,%f", &lng, &lat); err != nil {
		return &GeocodeResult{Address: address, Resolved: false}, nil
	}

	return &GeocodeResult{
		Address:  address,
		Lat:      lat,
		Lng:      lng,
		Resolved: true,
	}, nil
}
