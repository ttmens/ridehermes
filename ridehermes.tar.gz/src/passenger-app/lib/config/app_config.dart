/// 应用配置
/// 
/// API Key 通过编译时参数注入，不硬编码在源码中：
/// flutter build apk --dart-define=AMAP_WEB_KEY=xxx --dart-define=AMAP_ANDROID_KEY=xxx
/// 
/// 开发时可在 VS Code launch.json 或 IDE 运行配置中设置 dart-define。
class AppConfig {
  static const String appName = 'RideHermes';

  // ─── 后端地址 ───
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://ride.accseal.cn',
  );
  static const String apiPrefix = '/api/v1';

  // ─── WebSocket ───
  static const String wsUrl = String.fromEnvironment(
    'WS_URL',
    defaultValue: 'wss://ride.accseal.cn/ws/location',
  );

  // ─── 高德地图 Key（按平台区分，不可混用）───
  //
  // 1) Web服务 Key：用于 restapi.amap.com REST 接口（地理编码/路径规划）
  // 2) Android 平台 Key：绑定包名+签名SHA1，用于原生地图瓦片
  // 3) iOS 平台 Key：绑定 Bundle ID
  //
  // 编译时注入：
  //   --dart-define=AMAP_WEB_KEY=xxx
  //   --dart-define=AMAP_ANDROID_KEY=xxx
  //   --dart-define=AMAP_IOS_KEY=xxx
  static const String amapWebKey = String.fromEnvironment('AMAP_WEB_KEY');
  static const String amapAndroidKey = String.fromEnvironment('AMAP_ANDROID_KEY');
  static const String amapIosKey = String.fromEnvironment('AMAP_IOS_KEY');

  // ─── 超时配置 ───
  static const Duration connectTimeout = Duration(seconds: 10);
  static const Duration receiveTimeout = Duration(seconds: 30);
  static const Duration locationInterval = Duration(seconds: 3);
  static const Duration heartbeatInterval = Duration(seconds: 30);

  /// 检查必要配置是否已设置
  static List<String> get missingConfigs {
    final missing = <String>[];
    if (amapWebKey.isEmpty) missing.add('AMAP_WEB_KEY');
    if (amapAndroidKey.isEmpty) missing.add('AMAP_ANDROID_KEY');
    return missing;
  }
}
