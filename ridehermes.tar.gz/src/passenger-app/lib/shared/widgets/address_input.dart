import 'dart:async';
import 'package:flutter/material.dart';
import 'package:ride_hermes_passenger/config/theme.dart';
import 'package:ride_hermes_passenger/core/location/amap_service.dart';

class AddressInput extends StatefulWidget {
  final String label;
  final String hint;
  final IconData icon;
  final Color iconColor;
  final TextEditingController controller;
  final ValueChanged<String>? onAddressResolved;
  final String? city;

  const AddressInput({
    super.key,
    required this.label,
    required this.hint,
    required this.icon,
    required this.iconColor,
    required this.controller,
    this.onAddressResolved,
    this.city,
  });

  @override
  State<AddressInput> createState() => _AddressInputState();
}

class _AddressInputState extends State<AddressInput> {
  Timer? _debounce;
  final _amapService = AmapService();

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  void _onChanged(String text) {
    _debounce?.cancel();
    if (text.trim().isEmpty) return;
    _debounce = Timer(const Duration(milliseconds: 500), () async {
      final pos = await _amapService.geocode(text, city: widget.city);
      if (pos != null && mounted) {
        widget.onAddressResolved
            ?.call('${pos.latitude},${pos.longitude}');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controller,
      onChanged: _onChanged,
      decoration: InputDecoration(
        labelText: widget.label,
        prefixIcon: Icon(widget.icon, color: widget.iconColor),
        hintText: widget.hint,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
        ),
      ),
    );
  }
}
