package com.ridehermes.passenger

import android.app.Application
import android.content.pm.PackageManager
import android.util.Log
import com.amap.api.maps.MapsInitializer

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            MapsInitializer.updatePrivacyShow(this, true, true)
            MapsInitializer.updatePrivacyAgree(this, true)

            // 从 AndroidManifest meta-data 读取 API Key（由 build.gradle 注入）
            val appInfo = packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA)
            val apiKey = appInfo.metaData?.getString("com.amap.api.v2.apikey") ?: ""
            if (apiKey.isNotEmpty() && !apiKey.startsWith("\${")) {
                MapsInitializer.setApiKey(apiKey)
                Log.i("RideHermes", "AMap SDK initialized")
            } else {
                Log.w("RideHermes", "AMap API Key not configured. Set AMAP_API_KEY in gradle.properties or environment.")
            }
        } catch (e: Throwable) {
            Log.e("RideHermes", "AMap SDK init failed", e)
        }
    }
}
