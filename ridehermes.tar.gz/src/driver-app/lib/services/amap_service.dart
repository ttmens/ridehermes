import 'package:amap_flutter_base/amap_flutter_base.dart';
import 'package:dio/dio.dart';
import 'package:ride_hermes_driver/config/app_config.dart';

class AmapService {
  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 5),
    receiveTimeout: const Duration(seconds: 5),
  ));

  Future<LatLng?> geocode(String address, {String? city}) async {
    if (address.trim().isEmpty) return null;
    try {
      final params = <String, dynamic>{
        'key': AppConfig.amapApiKey,
        'address': address,
        'output': 'JSON',
      };
      if (city != null && city.isNotEmpty) {
        params['city'] = city;
      }
      final resp = await _dio.get(
        'https://restapi.amap.com/v3/geocode/geo',
        queryParameters: params,
      );
      final data = resp.data as Map<String, dynamic>;
      if (data['status'] == '1') {
        final codes = data['geocodes'] as List?;
        if (codes != null && codes.isNotEmpty) {
          final loc = codes[0]['location'] as String?;
          if (loc != null && loc.contains(',')) {
            final parts = loc.split(',');
            return LatLng(double.parse(parts[1]), double.parse(parts[0]));
          }
        }
      }
    } catch (_) {}
    return null;
  }

  Future<String?> reverseGeocode(double lat, double lng) async {
    try {
      final resp = await _dio.get(
        'https://restapi.amap.com/v3/geocode/regeo',
        queryParameters: {
          'key': AppConfig.amapApiKey,
          'location': '$lng,$lat',
          'output': 'JSON',
        },
      );
      final data = resp.data as Map<String, dynamic>;
      if (data['status'] == '1') {
        final regeo = data['regeocode'] as Map<String, dynamic>?;
        return regeo?['formatted_address'] as String?;
      }
    } catch (_) {}
    return null;
  }

  Future<List<LatLng>?> getDrivingRoute(LatLng origin, LatLng dest) async {
    try {
      final resp = await _dio.get(
        'https://restapi.amap.com/v3/direction/driving',
        queryParameters: {
          'key': AppConfig.amapApiKey,
          'origin': '${origin.longitude},${origin.latitude}',
          'destination': '${dest.longitude},${dest.latitude}',
          'output': 'JSON',
        },
      );
      final data = resp.data as Map<String, dynamic>;
      if (data['status'] == '1') {
        final route = data['route'] as Map<String, dynamic>?;
        final paths = route?['paths'] as List?;
        if (paths != null && paths.isNotEmpty) {
          final steps = paths[0]['steps'] as List;
          final points = <LatLng>[];
          for (final step in steps) {
            final polyline = step['polyline'] as String;
            for (final coord in polyline.split(';')) {
              final parts = coord.split(',');
              if (parts.length == 2) {
                points.add(LatLng(
                  double.parse(parts[1]),
                  double.parse(parts[0]),
                ));
              }
            }
          }
          return points;
        }
      }
    } catch (_) {}
    return null;
  }

  Future<String?> getCityFromLocation(double lat, double lng) async {
    try {
      final resp = await _dio.get(
        'https://restapi.amap.com/v3/geocode/regeo',
        queryParameters: {
          'key': AppConfig.amapApiKey,
          'location': '$lng,$lat',
          'output': 'JSON',
        },
      );
      final data = resp.data as Map<String, dynamic>;
      if (data['status'] == '1') {
        final regeo = data['regeocode'] as Map<String, dynamic>?;
        final comp = regeo?['addressComponent'] as Map<String, dynamic>?;
        if (comp != null) {
          final city = comp['city'];
          if (city is String && city.isNotEmpty) return city;
          final province = comp['province'];
          if (province is String && province.isNotEmpty) return province;
        }
      }
    } catch (_) {}
    return null;
  }
}
