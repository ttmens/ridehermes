/// 司机端应用配置
///
/// API Key 通过编译时参数注入：
/// flutter build apk --dart-define=AMAP_KEY=xxx --dart-define=AMAP_IOS_KEY=xxx
class AppConfig {
  static const String appName = 'RideHermes Driver';

  // ─── 后端地址 ───
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://ride.accseal.cn',
  );
  static const String apiPrefix = '/api/v1';

  // ─── WebSocket ───
  static const String wsUrl = String.fromEnvironment(
    'WS_URL',
    defaultValue: 'wss://ride.accseal.cn/ws/location',
  );

  // ─── 高德地图 Key ───
  // Android 平台 Key + iOS 平台 Key（编译时注入）
  static const String amapApiKey = String.fromEnvironment('AMAP_KEY');
  static const String amapApiKeyIos = String.fromEnvironment('AMAP_IOS_KEY');

  // ─── 超时配置 ───
  static const Duration connectTimeout = Duration(seconds: 10);
  static const Duration receiveTimeout = Duration(seconds: 15);
  static const Duration locationInterval = Duration(seconds: 3);
  static const Duration heartbeatInterval = Duration(seconds: 30);

  /// 检查必要配置
  static List<String> get missingConfigs {
    final missing = <String>[];
    if (amapApiKey.isEmpty) missing.add('AMAP_KEY');
    return missing;
  }
}
